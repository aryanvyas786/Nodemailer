import { Request, Response } from 'express';
import User from '../models/User';
import { upload } from '../middeware/multer';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs'
import generatePassword from '../services/PasswordGenertor';
import { sendRegistrationEmail } from '../services/emailService';
import sequelize from '../config/db';
import { log, profile } from 'console';
const JWT_SECRET = '12345'; 




export const registerUser = async (req: any, res: any) => {
  try {
    const { firstName, lastName, email, phone, gender, hobbies, userType, agencyId } = req.body;
    
    // Validate required fields
    if (!firstName || !lastName || !email || !phone || !gender || !userType) {
      return res.status(400).json({ message: 'All fields are required' });
    }

    console.log("typeof agencyId", typeof agencyId);

    // Check if user already exists
    const existingUser = await User.findOne({ where: { email } });
    if (existingUser) {
      return res.status(400).json({ message: 'Email already registered' });
    }

    // Generate random password and hash it
    const password = generatePassword();  // You should have a method to generate a random password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Access files
    const filesData = req.files as {
      profileImage?: Express.Multer.File[];
      resumeFile?: Express.Multer.File[];
    };

    console.log(filesData.profileImage)
    console.log(filesData.resumeFile);

    const profileImage = userType === '1' && filesData.profileImage ? filesData.profileImage[0].filename : null;
    const resumeFile = userType === '1' && filesData.resumeFile ? filesData.resumeFile[0].filename : null;

    console.log("profileImage{{{{", profileImage);

    // Create user record
    const user = await User.create({
      firstName,
      lastName,
      email,
      phone,
      gender,
      userType,
      hobbies: Array.isArray(hobbies) ? hobbies : [hobbies], // Ensure hobbies is an array
      profileImage,
      password: hashedPassword,
      resumeFile,
      agencyId: userType === '1' ? agencyId : null // Set agencyId only if Job Seeker
    });

    console.log("AgencyId", user.agencyId);
  
    // Send registration email
    await sendRegistrationEmail(email, firstName, password);
  
    // Send success response
    return res.status(201).json({ message: "User Registered Successfully", user });
  } catch (error) {
    console.error("Error message", error);
    return res.status(500).json({ error: "Internal server error" });
  }
};



export const loginUser = async (req: Request, res: any) => {
  const { email, password } = req.body;

  try {
    const user: any = await User.findOne({ where: { email } });
    if (!user) {
      return res.status(400).json({ message: 'Invalid email or password' });
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(400).json({ message: 'Invalid email or password' });
    }

    // Include firstName, lastName, and email in the JWT payload
    const token = jwt.sign(
      {
        userId: user.id,
        userType: user.userType,
        firstName: user.firstName, // Include firstName
        lastName: user.lastName,   // Include lastName
        email: user.email       
           // Include email
      },
      
      process.env.JWT_SECRET as string || JWT_SECRET, // Use the secret
      { expiresIn: '1h' }
    );
    console.log(user);
    

    // Set token in the cookie
    res.cookie('token', token, { httpOnly: true });

    // Send the token and user data in the response
    res.json({ message: 'Login successful', token, user });
  } catch (error) {
    res.status(500).json({ message: 'Error logging in' });
  }
};

  



export const dashboard = async (req: any, res: any) => {
  try {   
    // Extract the JWT from the Authorization header
    const token = req.headers.authorization?.split(' ')[1]; // Bearer <token>
    
    if (!token) {
      return res.status(401).json({ message: 'No token provided.' });
    }

    // Verify and decode the token
    const decoded: any = jwt.verify(token, process.env.JWT_SECRET as string || JWT_SECRET); 
    const userType = decoded.userType;   // Extract userType from decoded token
    const userId = decoded.userId;       // Extract userId from decoded token
    const firstName = decoded.firstName; // Extract firstName
    const lastName = decoded.lastName;   // Extract lastName
    const email = decoded.email;         // Extract email

    console.log('decoded token:', decoded.firstName); // Debugging log

    let userList: any[] = [];

    // If user is a Job Seeker (userType = 1), fetch agencies
    if (userType === '1') {
      userList = await User.findAll({
        where: {
          userType: 2, // Fetch only agencies (userType = 2)
        },
        attributes: ['id', 'firstName', 'lastName', 'gender', 'phone', 'email', 'usertype', 'profileImage', 'resumeFile'], // Only necessary fields
      });
    }
    // If user is an Agency (userType = 2), fetch job seekers associated with this agency
    else if (userType === '2') {
      userList = await User.findAll({
        where: {
          userType: 1,   // Fetch only job seekers (userType = 1)
          agencyId: userId, // Only job seekers associated with this agency (agencyId = agency's userId)
        },
        attributes: ['id', 'firstName', 'lastName', 'gender', 'phone', 'email', 'usertype', 'profileImage', 'resumeFile'], // Only necessary fields
      });
    } else {
      return res.status(400).json({ message: 'Invalid user type' });
    }

    // Construct full URLs for profile images and resumes
    const baseUrl = `${req.protocol}://${req.get('host')}/uploads/`;
    const updatedUserList = userList.map(user => ({
      ...user.toJSON(),
      profileImage: user.profileImage ? `${baseUrl}${user.profileImage}` : null,  // Full URL for profileImage
      resumeFile: user.resumeFile ? `${baseUrl}${user.resumeFile}` : null,        // Full URL for resumeFile
    }));

    // Include logged-in user's details
    const loggedInUserDetail = {
      firstName,
      lastName,
      email,
      userType,
      userId,
    };

    // Return the result with both the user list and logged-in user details
    return res.status(200).json({ updatedUserList, loggedInUserDetail });
  } catch (error) {
    console.error('Error fetching users:', error);
    return res.status(500).json({ message: 'Internal server error.' });
  }
};



