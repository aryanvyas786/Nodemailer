import { Router } from "express";
import { upload } from "../middeware/multer";
import {dashboard, loginUser, registerUser} from '../controllers/userController'
import { authMiddleware } from "../middeware/auth";
const router = Router();

router.post('/register', upload,  registerUser);
router.post("/login", loginUser);
router.get("/dashboard",dashboard);



export default router;